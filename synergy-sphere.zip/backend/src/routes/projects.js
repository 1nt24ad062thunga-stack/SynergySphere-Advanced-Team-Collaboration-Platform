// Placeholder Project Routes
const express = require('express');
const router = express.Router();

// GET /projects
router.get('/', (req, res) => {
  res.send('Get all projects placeholder');
});

// POST /projects
router.post('/', (req, res) => {
  res.send('Create new project placeholder');
});

module.exports = router;
