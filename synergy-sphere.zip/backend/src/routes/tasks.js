// Placeholder Task Routes
const express = require('express');
const router = express.Router();

// GET /tasks
router.get('/', (req, res) => {
  res.send('Get all tasks placeholder');
});

// POST /tasks
router.post('/', (req, res) => {
  res.send('Create new task placeholder');
});

module.exports = router;
