export default function App() {
  return (
    <div>
      <h1>SynergySphere Frontend Placeholder 🚀</h1>
    </div>
  );
}