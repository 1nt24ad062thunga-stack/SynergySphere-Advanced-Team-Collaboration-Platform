// Vite placeholder config
